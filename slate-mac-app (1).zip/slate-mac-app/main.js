const { app, BrowserWindow, ipcMain, dialog, Menu } = require('electron');
const fs = require('fs/promises');
const path = require('path');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 760,
    minWidth: 700,
    minHeight: 480,
    titleBarStyle: 'hiddenInset',
    backgroundColor: '#181a1f',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile('index.html');

  const template = [
    {
      label: app.name,
      submenu: [
        { role: 'about' },
        { type: 'separator' },
        { role: 'services' },
        { type: 'separator' },
        { role: 'hide' },
        { role: 'hideOthers' },
        { role: 'unhide' },
        { type: 'separator' },
        { role: 'quit' }
      ]
    },
    {
      label: 'File',
      submenu: [
        {
          label: 'New',
          accelerator: 'CmdOrCtrl+N',
          click: () => mainWindow.webContents.send('menu-new')
        },
        {
          label: 'Open…',
          accelerator: 'CmdOrCtrl+O',
          click: () => mainWindow.webContents.send('menu-open')
        },
        { type: 'separator' },
        {
          label: 'Save',
          accelerator: 'CmdOrCtrl+S',
          click: () => mainWindow.webContents.send('menu-save')
        },
        {
          label: 'Save As…',
          accelerator: 'CmdOrCtrl+Shift+S',
          click: () => mainWindow.webContents.send('menu-save-as')
        },
        { type: 'separator' },
        { role: 'close' }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'selectAll' },
        { type: 'separator' },
        {
          label: 'Find',
          accelerator: 'CmdOrCtrl+F',
          click: () => mainWindow.webContents.send('menu-find')
        }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    }
  ];

  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

ipcMain.handle('open-files', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile', 'multiSelections'],
    filters: [
      {
        name: 'Code and Text Files',
        extensions: ['txt', 'java', 'py', 'js', 'mjs', 'cjs', 'html', 'htm', 'css', 'json', 'c', 'h', 'cpp', 'cc', 'cxx', 'md']
      },
      { name: 'All Files', extensions: ['*'] }
    ]
  });

  if (result.canceled) return [];

  const files = [];
  for (const filePath of result.filePaths) {
    const content = await fs.readFile(filePath, 'utf8');
    files.push({
      path: filePath,
      name: path.basename(filePath),
      content
    });
  }
  return files;
});

ipcMain.handle('save-file', async (_event, payload) => {
  let filePath = payload.path;

  if (!filePath) {
    const result = await dialog.showSaveDialog(mainWindow, {
      defaultPath: payload.name || 'untitled.txt'
    });
    if (result.canceled || !result.filePath) return { canceled: true };
    filePath = result.filePath;
  }

  await fs.writeFile(filePath, payload.content, 'utf8');

  return {
    canceled: false,
    path: filePath,
    name: path.basename(filePath)
  };
});

ipcMain.handle('save-file-as', async (_event, payload) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: payload.name || 'untitled.txt'
  });

  if (result.canceled || !result.filePath) return { canceled: true };

  await fs.writeFile(result.filePath, payload.content, 'utf8');

  return {
    canceled: false,
    path: result.filePath,
    name: path.basename(result.filePath)
  };
});
