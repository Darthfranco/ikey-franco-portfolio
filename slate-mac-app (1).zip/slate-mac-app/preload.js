const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('slateAPI', {
  openFiles: () => ipcRenderer.invoke('open-files'),
  saveFile: (payload) => ipcRenderer.invoke('save-file', payload),
  saveFileAs: (payload) => ipcRenderer.invoke('save-file-as', payload),

  onMenuNew: (callback) => ipcRenderer.on('menu-new', callback),
  onMenuOpen: (callback) => ipcRenderer.on('menu-open', callback),
  onMenuSave: (callback) => ipcRenderer.on('menu-save', callback),
  onMenuSaveAs: (callback) => ipcRenderer.on('menu-save-as', callback),
  onMenuFind: (callback) => ipcRenderer.on('menu-find', callback)
});
