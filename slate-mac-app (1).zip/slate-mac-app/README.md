# Slate — macOS code text editor

Slate is a lightweight text editor for code. It is intentionally not an IDE.

## What works

- Open real files from your Mac
- Edit `.java`, `.py`, `.js`, `.html`, `.css`, `.json`, C and C++ files
- Save directly back to the original file
- Save As
- Tabs
- Syntax highlighting
- Line numbers
- Find / Replace
- Dark / light mode
- Native macOS menus and keyboard shortcuts

## Install and run

Open Terminal and run:

```bash
cd ~/Downloads/slate-mac-app
npm install
npm start
```

## Turn it into a normal Mac app

From the same folder:

```bash
npm run build:mac
```

When the build finishes, look inside:

```text
dist/
```

You should see a `.dmg` and/or `.zip`. Open the DMG and drag Slate into Applications.

## Keyboard shortcuts

- Command-N — New
- Command-O — Open
- Command-S — Save
- Command-Shift-S — Save As
- Command-F — Find
