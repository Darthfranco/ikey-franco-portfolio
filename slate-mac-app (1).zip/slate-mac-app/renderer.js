(() => {
  const editor = CodeMirror.fromTextArea(document.getElementById('editor'), {
    lineNumbers: true,
    lineWrapping: false,
    indentUnit: 4,
    tabSize: 4,
    indentWithTabs: false,
    autoCloseBrackets: true,
    matchBrackets: true,
    theme: 'material-darker',
    mode: 'text/plain'
  });

  const tabsEl = document.getElementById('tabs');
  const plusTab = document.getElementById('plusTab');
  const languageSelect = document.getElementById('languageSelect');

  const statusLanguage = document.getElementById('statusLanguage');
  const statusCursor = document.getElementById('statusCursor');
  const statusUnsaved = document.getElementById('statusUnsaved');

  const findPanel = document.getElementById('findPanel');
  const findInput = document.getElementById('findInput');
  const replaceInput = document.getElementById('replaceInput');

  let docs = [];
  let currentId = null;
  let nextId = 1;
  let fontSize = 15;

  const extensionMap = {
    java: 'text/x-java',
    py: 'text/x-python',
    js: 'javascript',
    mjs: 'javascript',
    cjs: 'javascript',
    html: 'text/html',
    htm: 'text/html',
    css: 'css',
    json: 'application/json',
    c: 'text/x-csrc',
    h: 'text/x-csrc',
    cpp: 'text/x-c++src',
    cc: 'text/x-c++src',
    cxx: 'text/x-c++src',
    txt: 'text/plain',
    md: 'text/plain'
  };

  function detectMode(filename) {
    const ext = (filename.split('.').pop() || '').toLowerCase();
    return extensionMap[ext] || 'text/plain';
  }

  function modeLabel(mode) {
    const opt = [...languageSelect.options].find(o => o.value === mode);
    return opt ? opt.textContent : 'Plain Text';
  }

  function currentDoc() {
    return docs.find(d => d.id === currentId);
  }

  function syncCurrent() {
    const doc = currentDoc();
    if (!doc) return;
    doc.content = editor.getValue();
    doc.cursor = editor.getCursor();
  }

  function renderTabs() {
    [...tabsEl.querySelectorAll('.tab')].forEach(el => el.remove());

    docs.forEach(doc => {
      const tab = document.createElement('div');
      tab.className = 'tab' + (doc.id === currentId ? ' active' : '');

      const name = document.createElement('span');
      name.className = 'tab-name';
      name.textContent = (doc.dirty ? '• ' : '') + doc.name;

      const close = document.createElement('span');
      close.className = 'tab-close';
      close.textContent = '×';

      tab.append(name, close);
      tabsEl.insertBefore(tab, plusTab);

      tab.addEventListener('click', e => {
        if (e.target !== close) switchTo(doc.id);
      });

      close.addEventListener('click', e => {
        e.stopPropagation();
        closeDoc(doc.id);
      });
    });
  }

  function newFile(content = '', name = null, path = null) {
    syncCurrent();

    const doc = {
      id: nextId++,
      name: name || `untitled-${nextId - 1}.txt`,
      path,
      content,
      mode: detectMode(name || ''),
      dirty: false,
      cursor: { line: 0, ch: 0 }
    };

    docs.push(doc);
    currentId = doc.id;
    loadDoc(doc);
  }

  function switchTo(id) {
    if (id === currentId) return;
    syncCurrent();
    currentId = id;
    loadDoc(currentDoc());
  }

  function loadDoc(doc) {
    if (!doc) return;

    editor.off('change', onEditorChange);
    editor.setValue(doc.content || '');
    editor.setOption('mode', doc.mode);
    editor.setCursor(doc.cursor || { line: 0, ch: 0 });
    editor.on('change', onEditorChange);

    languageSelect.value = doc.mode;
    renderTabs();
    updateStatus();
    editor.focus();
    setTimeout(() => editor.refresh(), 0);
  }

  function closeDoc(id) {
    const doc = docs.find(d => d.id === id);
    if (!doc) return;

    if (doc.dirty && !confirm(`"${doc.name}" has unsaved changes. Close anyway?`)) return;

    const index = docs.findIndex(d => d.id === id);
    docs.splice(index, 1);

    if (!docs.length) {
      currentId = null;
      newFile();
      return;
    }

    if (currentId === id) {
      const fallback = docs[Math.min(index, docs.length - 1)];
      currentId = fallback.id;
      loadDoc(fallback);
    } else {
      renderTabs();
    }
  }

  function onEditorChange() {
    const doc = currentDoc();
    if (!doc) return;
    doc.content = editor.getValue();
    doc.dirty = true;
    renderTabs();
    updateStatus();
  }

  editor.on('change', onEditorChange);

  editor.on('cursorActivity', () => {
    const pos = editor.getCursor();
    statusCursor.textContent = `Ln ${pos.line + 1}, Col ${pos.ch + 1}`;
    const doc = currentDoc();
    if (doc) doc.cursor = pos;
  });

  function updateStatus() {
    const doc = currentDoc();
    if (!doc) return;
    statusLanguage.textContent = modeLabel(doc.mode);
    statusUnsaved.textContent = doc.dirty ? 'Unsaved' : 'Saved';
    document.title = `${doc.dirty ? '• ' : ''}${doc.name} — Slate`;
  }

  async function openFiles() {
    const files = await window.slateAPI.openFiles();
    for (const file of files) {
      newFile(file.content, file.name, file.path);
    }
  }

  async function saveCurrent(saveAs = false) {
    syncCurrent();
    const doc = currentDoc();
    if (!doc) return;

    const payload = {
      path: doc.path,
      name: doc.name,
      content: doc.content
    };

    const result = saveAs
      ? await window.slateAPI.saveFileAs(payload)
      : await window.slateAPI.saveFile(payload);

    if (!result || result.canceled) return;

    doc.path = result.path;
    doc.name = result.name;
    doc.mode = detectMode(doc.name);
    doc.dirty = false;

    editor.setOption('mode', doc.mode);
    languageSelect.value = doc.mode;
    renderTabs();
    updateStatus();
  }

  function openFind() {
    findPanel.classList.add('show');
    const selection = editor.getSelection();
    if (selection && !selection.includes('\n')) findInput.value = selection;
    findInput.focus();
    findInput.select();
  }

  function closeFind() {
    findPanel.classList.remove('show');
    editor.focus();
  }

  function findNext(backwards = false) {
    const query = findInput.value;
    if (!query) return;

    const start = backwards ? editor.getCursor('from') : editor.getCursor('to');
    let cursor = editor.getSearchCursor(query, start);
    let found = backwards ? cursor.findPrevious() : cursor.findNext();

    if (!found) {
      const wrap = backwards
        ? CodeMirror.Pos(editor.lastLine(), editor.getLine(editor.lastLine()).length)
        : CodeMirror.Pos(0, 0);

      cursor = editor.getSearchCursor(query, wrap);
      found = backwards ? cursor.findPrevious() : cursor.findNext();
    }

    if (found) {
      editor.setSelection(cursor.from(), cursor.to());
      editor.scrollIntoView({ from: cursor.from(), to: cursor.to() }, 80);
    }
  }

  function replaceOne() {
    if (!findInput.value) return;
    if (editor.getSelection() === findInput.value) {
      editor.replaceSelection(replaceInput.value, 'around');
    }
    findNext(false);
  }

  function replaceAll() {
    const query = findInput.value;
    if (!query) return;

    editor.operation(() => {
      const cursor = editor.getSearchCursor(query, CodeMirror.Pos(0, 0));
      while (cursor.findNext()) cursor.replace(replaceInput.value);
    });
  }

  document.getElementById('newBtn').addEventListener('click', () => newFile());
  plusTab.addEventListener('click', () => newFile());
  document.getElementById('openBtn').addEventListener('click', openFiles);
  document.getElementById('saveBtn').addEventListener('click', () => saveCurrent(false));

  languageSelect.addEventListener('change', () => {
    const doc = currentDoc();
    if (!doc) return;
    doc.mode = languageSelect.value;
    editor.setOption('mode', doc.mode);
    updateStatus();
  });

  document.getElementById('fontUp').addEventListener('click', () => {
    fontSize = Math.min(28, fontSize + 1);
    document.documentElement.style.setProperty('--font-size', `${fontSize}px`);
    editor.refresh();
  });

  document.getElementById('fontDown').addEventListener('click', () => {
    fontSize = Math.max(10, fontSize - 1);
    document.documentElement.style.setProperty('--font-size', `${fontSize}px`);
    editor.refresh();
  });

  document.getElementById('themeBtn').addEventListener('click', () => {
    document.body.classList.toggle('dark');
    const dark = document.body.classList.contains('dark');
    editor.setOption('theme', dark ? 'material-darker' : 'default');
    document.getElementById('themeBtn').textContent = dark ? '☾' : '☀';
    setTimeout(() => editor.refresh(), 0);
  });

  document.getElementById('findPrev').addEventListener('click', () => findNext(true));
  document.getElementById('findNext').addEventListener('click', () => findNext(false));
  document.getElementById('replaceOne').addEventListener('click', replaceOne);
  document.getElementById('replaceAll').addEventListener('click', replaceAll);

  findInput.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      findNext(e.shiftKey);
    } else if (e.key === 'Escape') {
      closeFind();
    }
  });

  replaceInput.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      replaceOne();
    } else if (e.key === 'Escape') {
      closeFind();
    }
  });

  window.slateAPI.onMenuNew(() => newFile());
  window.slateAPI.onMenuOpen(openFiles);
  window.slateAPI.onMenuSave(() => saveCurrent(false));
  window.slateAPI.onMenuSaveAs(() => saveCurrent(true));
  window.slateAPI.onMenuFind(openFind);

  window.addEventListener('keydown', e => {
    if (e.key === 'Escape' && findPanel.classList.contains('show')) closeFind();
  });

  newFile(
`public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}`,
    'Main.java',
    null
  );
})();
